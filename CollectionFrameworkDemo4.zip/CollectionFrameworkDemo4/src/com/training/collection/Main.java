package com.training.collection;

import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		
		Car c1  =  new Car("TN223344","Hyundai","i10");
		
		Car c2  =  new Car("PY223354","Honda","city");
		
		Car c3 =  new Car("KL223356","Maruti","Swift");
		
		
		
		
		Map carOwners = new HashMap<Car,String>();
		
		carOwners.put(c1, "Kumar");
		
		carOwners.put(c2, "Ravi");
		
		carOwners.put(c3, "Vijay");
				
		Car key1 =new Car("TN223344","Hyundai","i10");
		
		
		System.out.println("Owner of Hyundai i10 car : " +carOwners.get(key1));
		
		Car key2 = new Car("PY223354","Honda","city");
		
		System.out.println("Owner of Honda city car : " +carOwners.get(key2));
		Car key3 = new Car("KL223357","Maruti","Swift");
		
		
		System.out.println("Owner of Maruti Swift car : " +carOwners.get(key3 ));
	}

}
