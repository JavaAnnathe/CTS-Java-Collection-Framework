//package com.training.collection;


public class Car {
	
	private String registrationNumber;
	
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	private String model;
	
	private String brand;
	
	public Car() {
		
		
	}
	
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public String getModel() {
		return model;
	}

	public String getBrand() {
		return brand;
	}

	public Car(String registrationNumber,String brand,String model) {
		
		this.registrationNumber = registrationNumber;
		this.brand = brand;
		this.model = model;
	}
	
	public void applyBrake() {
		
		System.out.println("Brake applied in car");
		
	}

	public void applyAccelarate() {
		
		System.out.println("Accelaration applied in car");
		
				
	}
	
	
	public boolean equals(Object obj) {
		
		Car car = (Car)obj;
		
		boolean isEqual = false;
		
		if((this.registrationNumber.equals( car.registrationNumber)) && (this.brand.equals( car.brand)) && (this.model.equals(car.model))) {
			
			isEqual =true;
		}
		
		
		return isEqual;
	}
	
	
	public String toString() {
		
		String details = null;
		
		details = "This is a "+ brand + " Car with " +model+ " model."+ " It's registration number is "+registrationNumber;
		
		return details;
	}

	@Override
	public int hashCode() {
		//final int prime = 31;
		//int result = 1;
		//result = prime * result + ((registrationNumber == null) ? 0 : registrationNumber.hashCode());
		return 1;
	}

	
}
