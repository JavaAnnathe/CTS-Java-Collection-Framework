//package com.training.collection;


public class Car {
	
	private String registrationNumber;
	
	private String model;
	
	private String brand;
	
	

	public Car(String registrationNumber,String brand,String model) {
		
		this.registrationNumber = registrationNumber;
		this.brand = brand;
		this.model = model;
	}
	
	
	
	
	public boolean equals(Object obj) {
		
		Car car = (Car)obj;
		
		boolean isEqual = false;
		
		if((this.registrationNumber.equals( car.registrationNumber)) && (this.brand.equals( car.brand)) && (this.model.equals(car.model))) {
			
			isEqual =true;
		}
		
		
		return isEqual;
	}
	
	
	
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		result = prime * result + ((registrationNumber == null) ? 0 : registrationNumber.hashCode());
		return result;
		//return 5;
	}

	
}
