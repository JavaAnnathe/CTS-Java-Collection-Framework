import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
public class ArrayListDemo3 {

	public static void main(String[] args) {
		
		List<Car> cars = new ArrayList<Car>();
		
		
		Car c1 = new Car("Honda","City","TN11CC67");
		Car c2 = new Car("Maruti","Swift","TN12BB57");
		Car c3 = new Car("Audi","XX","TN12CC67");
		Car c4 = new Car("Tata","Indica","TN15CC60");
		Car c5 = new Car("Hyundai","i20","KA10CC67");
		
		
		cars.add(c1);
		cars.add(c2);
		cars.add(c3);
		cars.add(c4);
		cars.add(c5);
		
		for(int i=0; i<cars.size();i++){
			Car c=cars.get(i);
			System.out.println(c);
		}
		
		//Collections.sort(cars);
		BrandComparator bc = new BrandComparator();
		Collections.sort(cars, bc);
		System.out.println("After sorting");
		
		for(int i=0; i<cars.size();i++){
			Car c=cars.get(i);
			System.out.println(c);
		}
		
	}

}
