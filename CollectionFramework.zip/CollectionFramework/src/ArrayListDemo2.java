import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class ArrayListDemo2 {

	public static void main(String[] args) {
		
		List<String> nameList = new ArrayList<String>();
		
		nameList.add("Kumar");
		nameList.add("Ravi");
		nameList.add("Magesh");
		nameList.add("Chandran");
		nameList.add("Vinay");
		nameList.add("Bala");
		
		for(int i=0; i<nameList.size();i++){
			System.out.println("Name:"+nameList.get(i));
		}
		
		Collections.sort(nameList);
		System.out.println("After sorting");
		
		for(int i=0; i<nameList.size();i++){
			System.out.println("Name:"+nameList.get(i));
		}
		
	}

}
