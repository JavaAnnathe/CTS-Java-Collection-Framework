
public class ArrayDemo {

	public static void main(String[] args) {
		
		float[] students = new float[5];
		students[0]=8.5f;
		students[1]=9.0f;
		students[2]=7.5f;
		students[3]=8.0f;
		students[4]=7.0f;
		//limitation of using array as it has fixed size
		//students[5]=9.5f;
		System.out.println("Student CGPA:"+students[3]);
		for(int i=0; i<students.length;i++){
			System.out.println("Student CGPA:"+students[i]);
		}

	}

}
