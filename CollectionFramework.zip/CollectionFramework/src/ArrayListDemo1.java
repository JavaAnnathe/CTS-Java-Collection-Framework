import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo1 {

	public static void main(String[] args) {
		//generics
		List<Float> students = new ArrayList<Float>();
		students.add(8.5f);
		//students.add("Kumar");
		System.out.println("Student CGPA:"+students.get(0));

	}

}
