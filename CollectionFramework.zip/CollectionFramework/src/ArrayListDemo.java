import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		ArrayList students = new ArrayList();

		//standard way of declaring
		List subjects = new ArrayList();
		
		students.add(8.5);
		students.add(1, 7.5);
		students.add(0,9);
		students.add(6.5);
		students.add("Kumar");
		
		
		System.out.println("Student CGPA:"+students.get(2));
		
		for(int i=0;i<students.size();i++){
			System.out.println("Student CGPA:"+students.get(i));
			
		}

	}

}
