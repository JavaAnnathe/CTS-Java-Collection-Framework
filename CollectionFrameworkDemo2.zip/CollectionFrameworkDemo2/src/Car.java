
public class Car  {
	
	private String brand;
	private String model;
	private String registrationNo;
	
	public Car(String brand, String model, String registrationNo) {
		super();
		this.brand = brand;
		this.model = model;
		this.registrationNo = registrationNo;
	}

	public String getBrand() {
		return brand;
	}

	public String getModel() {
		return model;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}
	
	public void applyBrake(){
		System.out.println("Brake is applied");
	}
	public void applyAccelarator(){
		System.out.println("Accelarator is applied");
	}

	@Override
	public String toString() {
		//return "Java is easy to learn";
		return "Car [brand=" + brand + ", model=" + model + ", registrationNo=" + registrationNo + "]";
	}

	/*
	 * @Override public int compareTo(Car c) {
	 * 
	 * return this.registrationNo.compareTo(c.getRegistrationNo()); }
	 */
	
}
